// i) Create two arrays
const collegeFriends = ["Sweety", "Varun", "Ramesh"];
const workFriends = ["Anita", "Priya", "Vamsi"];

// Merge arrays using SPREAD operator
const partyList = ["Me", ...collegeFriends, ...workFriends];

// ii) Function using normal parameter + REST operator
const welcomeParty = (host, ...guests) => {
    return `Host: ${host}\nGuests: ${guests.join(", ")}`;
};

// Display output
document.getElementById("output").textContent =
    `Party List:
${partyList.join(", ")}

${welcomeParty("Me", ...partyList)}`;
